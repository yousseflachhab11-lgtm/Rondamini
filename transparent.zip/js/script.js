document.addEventListener('DOMContentLoaded', function() {
  console.log('Project transparent is ready!');
});